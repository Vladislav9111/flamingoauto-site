const form = document.getElementById('car-form');
const popup = document.getElementById('popup');
const closeBtn = document.querySelector('.close-btn');
const photoInput = document.getElementById('photos');
const photoError = document.getElementById('photo-error');


// === Image compression & 5MB budget ===
async function compressImagesToBudget(files, budgetBytes = 5*1024*1024) {
    const out = [];
    let used = 0;

    async function fileToImageBitmap(file){
        if ('createImageBitmap' in window) {
            return await createImageBitmap(file);
        }
        return await new Promise((res, rej) => {
            const url = URL.createObjectURL(file);
            const img = new Image();
            img.onload = () => { URL.revokeObjectURL(url); res(img); };
            img.onerror = rej;
            img.src = url;
        });
    }
    function drawScaled(img, maxSide){
        const w0 = img.width || img.naturalWidth;
        const h0 = img.height || img.naturalHeight;
        const scale = Math.min(1, maxSide / Math.max(w0, h0));
        const w = Math.max(1, Math.round(w0 * scale));
        const h = Math.max(1, Math.round(h0 * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        return canvas;
    }
    function canvasToBlob(canvas, mime, quality){
        return new Promise(res => canvas.toBlob(res, mime, quality));
    }

    const MAX_SIDE_STEPS = [2000, 1600, 1280];
    const QUALITY_STEPS = [0.82, 0.72, 0.62, 0.55, 0.5, 0.45];

    for (let i=0;i<files.length;i++){
        const f = files[i];
        if (!/^image\//i.test(f.type)) {
            if (used + f.size > budgetBytes) throw new Error('OVER_BUDGET');
            out.push(f); used += f.size; continue;
        }
        const img = await fileToImageBitmap(f);
        let bestBlob = null;

        for (const side of MAX_SIDE_STEPS) {
            const canvas = drawScaled(img, side);
            for (const q of QUALITY_STEPS) {
                const mime = 'image/webp';
                const blob = await canvasToBlob(canvas, mime, q);
                const remaining = budgetBytes - used;
                const perFileBudget = Math.max(200*1024, Math.floor(remaining / (files.length - i)));
                if (blob && blob.size <= perFileBudget) { bestBlob = blob; break; }
                bestBlob = blob; // keep last attempt
            }
            if (bestBlob) {
                const remaining = budgetBytes - used;
                if (bestBlob.size <= remaining) break;
            }
        }
        if (!bestBlob) throw new Error('COMPRESSION_FAILED');
        if (used + bestBlob.size > budgetBytes) throw new Error('OVER_BUDGET');
        const name = f.name.replace(/\.(png|jpe?g|gif|heic|heif|webp)$/i, '') + '.webp';
        out.push(new File([bestBlob], name, {type: 'image/webp'}));
        used += bestBlob.size;
    }
    return out;
}
// Initialize language on page load
document.addEventListener('DOMContentLoaded', function() {
    // Check multiple ways to determine if it's Russian
    const isRussian = window.location.pathname.includes('ru.html') || 
                     window.location.pathname.includes('/ru.html') ||
                     window.location.pathname.endsWith('ru') ||
                     document.documentElement.lang === 'ru' ||
                     document.querySelector('html[lang="ru"]') !== null ||
                     document.title.includes('Продайте авто');
    
    // Debug: log current language detection
    console.log('Current path:', window.location.pathname);
    console.log('HTML lang:', document.documentElement.lang);
    console.log('Document title:', document.title);
    console.log('Is Russian:', isRussian);
    
    // Update button texts
    const submitBtn = document.getElementById('submit-btn');
    const heroBtn = document.querySelector('.btn');
    const popupMessage = document.querySelector('#popup p');
    
    if (isRussian) {
        if (submitBtn) submitBtn.textContent = 'Отправить заявку';
        if (heroBtn) heroBtn.textContent = 'Отправить заявку';
        if (popupMessage) popupMessage.textContent = 'Ваша заявка отправлена';
        console.log('Set Russian language');
    } else {
        if (submitBtn) submitBtn.textContent = 'Saada päring';
        if (heroBtn) heroBtn.textContent = 'Saada päring';
        if (popupMessage) popupMessage.textContent = 'Teie ankeet on saadetud';
        console.log('Set Estonian language');
    }
});

function validatePhotos() {
    photoError.textContent = '';
    if (photoInput.files.length > 6) {
        // Check current page language for error message
        const isRussian = window.location.pathname.includes('ru.html') || 
                         window.location.pathname.includes('/ru.html') ||
                         window.location.pathname.endsWith('ru') ||
                         document.documentElement.lang === 'ru' ||
                         document.title.includes('Продайте авто');
        photoError.textContent = isRussian 
            ? 'Можно загрузить не более 6 фотографий.'
            : 'Saate üles laadida mitte rohkem kui 6 fotot.';
        return false;
    }
    return true;
}

photoInput.addEventListener('change', validatePhotos);

form.addEventListener('submit', async function(event) {
    event.preventDefault();

    const arePhotosValid = validatePhotos();
    
    // Force validation UI to show on all fields
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    const isFormValid = form.checkValidity();

    if (isFormValid && arePhotosValid) {
        const submitButton = document.getElementById('submit-btn');
        const isRussian = window.location.pathname.includes('ru.html') || 
                         window.location.pathname.includes('/ru.html') ||
                         window.location.pathname.endsWith('ru') ||
                         document.documentElement.lang === 'ru' ||
                         document.title.includes('Продайте авто');
        
        submitButton.disabled = true;
        submitButton.textContent = isRussian ? 'Отправка...' : 'Saatmine...';

        const formElements = form.elements;

        // Prepare form data with photos
        const formData = new FormData();

        // Add text fields
        formData.append('regNumber', formElements['reg-number'].value);
        formData.append('make', formElements['make'].value);
        formData.append('model', formElements['model'].value);
        formData.append('year', formElements['year'].value);
        formData.append('mileage', formElements['mileage'].value);
        formData.append('transmission', formElements['transmission'].value);
        formData.append('engine', formElements['engine'].value);
        formData.append('price', formElements['price'].value);
        formData.append('name', formElements['name'].value);
        formData.append('email', formElements['email'].value);
        formData.append('phone', formElements['phone'].value);
        formData.append('city', formElements['city'].value);
        formData.append('note', formElements['note'].value);

        // Add photos with compression to <=5MB total
        const originalFiles = Array.from(photoInput.files || []);
        let compressedFiles = [];
        try {
            compressedFiles = await compressImagesToBudget(originalFiles, 5*1024*1024);
        } catch (e) {
            const isRu = window.location.pathname.includes('ru.html') || document.documentElement.lang==='ru';
            photoError.textContent = isRu ? 'Даже после сжатия файлы превышают 5 МБ. Уберите часть изображений или уменьшите их.' : 'Isegi pärast tihendamist ületavad fotod 5 MB. Eemaldage mõned pildid või vähendage neid.';
            submitButton.disabled = false;
            submitButton.textContent = isRu ? 'Отправить заявку' : 'Saada päring';
            return;
        }
        compressedFiles.slice(0,6).forEach((f, i) => {
            formData.append(`photo${i}`, f, f.name);
        });
        formData.append('photoCount', String(compressedFiles.length));


        try {
            // Send to Netlify Function (with photos)
            const response = await fetch('/.netlify/functions/send-telegram', {
                method: 'POST',
                body: formData // No Content-Type header for FormData
            });

            if (response.status === 413) {
                const isRu = window.location.pathname.includes('ru.html') || document.documentElement.lang==='ru';
                photoError.textContent = isRu ? 'Слишком большой объём вложений. Ограничение — 5 МБ.' : 'Liiga suur manuste maht. Piirang — 5 MB.';
                submitButton.disabled = false;
                submitButton.textContent = isRu ? 'Отправить заявку' : 'Saada päring';
                return;
            }
            const result = await response.json();

            if (response.ok && result.success) {
                // Show success popup
                popup.classList.remove('hidden');
                form.reset();
                photoError.textContent = '';
            } else {
                throw new Error(result.error || 'Unknown error');
            }

        } catch (error) {
            console.error('Form submission error:', error);
            const errorMessage = isRussian 
                ? 'Не удалось отправить заявку. Пожалуйста, попробуйте еще раз.'
                : 'Küsimustikku ei õnnestunud saata. Palun proovige uuesti.';
            alert(errorMessage);
        } finally {
            submitButton.disabled = false;
            submitButton.textContent = isRussian ? 'Отправить заявку' : 'Saada päring';
        }

    } else {
        console.log('Form submission failed validation.');
        if(!isFormValid) form.reportValidity();
    }
});

function closePopup() {
    popup.classList.add('hidden');
}

closeBtn.addEventListener('click', closePopup);

popup.addEventListener('click', function(event) {
    // Close popup if the background overlay is clicked
    if (event.target === popup) {
        closePopup();
    }
});

// Insert dynamic year for both pages if elements exist
(function setFooterYear() {
    const year = new Date().getFullYear();
    const elEt = document.getElementById('year-et');
    const elRu = document.getElementById('year-ru');
    if (elEt) elEt.textContent = year;
    if (elRu) elRu.textContent = year;
})();

// Language switch initialization
(function initLangSwitch() {
    const switchContainer = document.querySelector('.lang-switch');
    if (!switchContainer) return;

    const buttons = switchContainer.querySelectorAll('.lang-btn');
    buttons.forEach(btn => {
        // Make Enter/Space activate link for keyboard users
        btn.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                btn.click();
            }
        });

        // Set aria-pressed based on href matching current location
        try {
            const href = new URL(btn.href, location.href).pathname.split('/').pop();
            const current = location.pathname.split('/').pop() || 'index.html';
            btn.setAttribute('aria-pressed', href === current ? 'true' : 'false');
            if (href === current) btn.classList.add('active');
        } catch (e) {
            // Ignore URL errors
        }
    });
})();

// Debug function for testing Telegram integration
window.testTelegramFunction = async function() {
    console.log('🧪 Testing Telegram function...');

    const testData = {
        name: 'Test User',
        email: 'test@example.com',
        phone: '+372 12345678',
        regNumber: '123 ABC',
        make: 'Volkswagen',
        model: 'Golf',
        city: 'Tallinn',
        note: 'Test message from debug function'
    };

    try {
        const response = await fetch('/.netlify/functions/send-telegram', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(testData)
        });

        const result = await response.json();

        if (response.ok) {
            console.log('✅ Telegram test SUCCESS:', result);
            alert('✅ Telegram test successful! Check console for details.');
        } else {
            console.error('❌ Telegram test FAILED:', result);
            alert('❌ Telegram test failed: ' + (result.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('❌ Network error:', error);
        alert('❌ Network error: ' + error.message);
    }
};

// Debug function for language detection
window.debugLanguage = function() {
    const isRussian = window.location.pathname.includes('ru.html') || 
                     window.location.pathname.includes('/ru.html') ||
                     window.location.pathname.endsWith('ru') ||
                     document.documentElement.lang === 'ru' ||
                     document.title.includes('Продайте авто');
    
    console.log('🔍 Language Debug Info:');
    console.log('- Current path:', window.location.pathname);
    console.log('- HTML lang:', document.documentElement.lang);
    console.log('- Document title:', document.title);
    console.log('- Includes ru.html:', window.location.pathname.includes('ru.html'));
    console.log('- Includes /ru.html:', window.location.pathname.includes('/ru.html'));
    console.log('- Ends with ru:', window.location.pathname.endsWith('ru'));
    console.log('- Title includes Продайте авто:', document.title.includes('Продайте авто'));
    console.log('- Final isRussian:', isRussian);
    
    alert(`Language detection: ${isRussian ? 'Russian' : 'Estonian'}`);
};
