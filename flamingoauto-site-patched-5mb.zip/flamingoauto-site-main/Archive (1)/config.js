// This file contains sensitive information.
// In a real project, this file should be added to .gitignore to avoid committing secrets to version control.
// However, for this client-side-only project, please be aware that these values are still visible to anyone inspecting the site's source code.
// The proper way to secure this token is to use a server-side proxy which you can build later.

export const BOT_TOKEN = '7977191085:AAE97XWPra90KKlBgy1KdDrZCE3UV1vPIOM';
export const CHAT_ID = '712470612';
export const ADMIN_PASS = 'sevvun-zyxmoc-Veggy8';